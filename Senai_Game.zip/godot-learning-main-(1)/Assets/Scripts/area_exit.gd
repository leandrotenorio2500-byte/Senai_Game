extends Area2D
class_name AreaExit

@export var sprite : Sprite2D

var is_open = false

func _ready():
	close()

func open():
	is_open = true
	sprite.region_rect.position.x = 22
	
func close():
	is_open = false
	sprite.region_rect.position.x = 0

func _on_body_entered(body):
	print("Algo entrou na área: ", body.name) # Debug 1
	if is_open && body is PlayerController:
		print("Porta aberta e é o player! Mudando de fase...") # Debug 2
		GameManager.next_level()

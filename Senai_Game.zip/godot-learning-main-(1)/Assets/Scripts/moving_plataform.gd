extends Path2D
class_name MovingPlataform

@export var speed : float = 65.0 # pixels por segundo
@export var ease : Tween.EaseType
@export var transition : Tween.TransitionType
@export var path_follow_2D : PathFollow2D

func _ready():
	move_tween()

func move_tween():
	var curve_length = curve.get_baked_length()
	var duration = curve_length / speed

	var tween = get_tree().create_tween().set_loops()

	tween.tween_property(
		path_follow_2D,
		"progress",
		curve_length,
		duration
	).set_ease(ease).set_trans(transition)

	tween.tween_property(
		path_follow_2D,
		"progress",
		0.0,
		duration
	).set_ease(ease).set_trans(transition)

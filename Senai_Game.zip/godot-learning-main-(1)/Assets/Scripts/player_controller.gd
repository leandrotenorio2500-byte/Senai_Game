extends CharacterBody2D
class_name PlayerController

@export var speed = 10.0
@export var jump_power = 10.0

var speed_multiplier = 10.0
var jump_multiplier = -20.0
var direction = 0

#const SPEED = 100.0
#const JUMP_VELOCITY = -200.0

func _input(event):
	# Handle jump down.
	if event.is_action("move_down"):
		set_collision_mask_value(10, false)
	else:
		set_collision_mask_value(10, true)

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
#		The value multiplied after delta works to reduce effect of gravity :D
		velocity += get_gravity() * delta * 0.65
		
	# While press jumping button will continuos jumping
	if Input.is_action_pressed("jump") and is_on_floor():
		velocity.y = jump_power * jump_multiplier

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	direction = Input.get_axis("move_left", "move_right")
	if direction:
		velocity.x = direction * speed * speed_multiplier
	else:
		velocity.x = move_toward(velocity.x, 0, speed * speed_multiplier)	

	move_and_slide()

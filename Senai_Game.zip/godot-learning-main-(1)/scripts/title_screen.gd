extends Control
@onready var start: Button = $MarginContainer/HBoxContainer/VBoxContainer/Start
@onready var credits: Button = $MarginContainer/HBoxContainer/VBoxContainer/Credits
@onready var quit: Button = $MarginContainer/HBoxContainer/VBoxContainer/Quit

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://scene/chegada.tscn")

func _on_credits_pressed() -> void:
	pass # Replace with function body.


func _on_quit_pressed() -> void:
	get_tree().quit()
